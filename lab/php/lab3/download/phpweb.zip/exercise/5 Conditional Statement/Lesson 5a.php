<html>
<head><title>Lesson 5a: Conditional Statement(if statement) </title><head>
<body>

<?php

$age = 20;
 if( $age > 18 )
   {
    echo "<b>Qualifies for driving</b>";
    }

?>
 
</body>
</html>