<html>
<head><title>Lesson 5b: Conditional Statement(if else statement) </title><head>
<body>

<?php

$age = 15;
if( $age > 18 ){
   echo "<b>Qualifies for driving</b>";
}
else{
   echo "<b>Does not qualify for driving</b>";
}

?>
 
</body>
</html>