<!DOCTYPE html>
<html>
<head>
<title> Lesson 3a: Creating (Declaring) PHP Variables</title>
</head>

<body>

<?php
//declare var
$txt="Hello world!";
$x=5;
$y=10.5;
$z=$x+$y;
$txt1="WELCOME to PHP!";

//string


//number


//more string var


?>




<?php
//The following example will output the sum of two variables:

?>


</body>
</html>
