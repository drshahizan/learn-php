<html>
<head>
<title>Lesson 7b: Get The Length of an Array </title>
</head>

<body>

<?php
$cars=array("Volvo","BMW","Toyota");
echo count($cars);
/* 	The count() function is used to return the 
	length (the number of elements) of an array. 
*/
?>

</body>
</html>