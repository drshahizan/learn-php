<html>
<head><title>Lesson 4b: Assignment Operators</title><head>
<body>

<?php
$x=10;
echo $x;
echo "<br>";

$y=20;
$y += 100;
echo $y;
echo "<br>";

$z=50;
$z -= 25;
echo $z;
echo "<br>";

$i=5;
$i *= 6;
echo $i;
echo "<br>";

$j=10;
$j /= 5;
echo $j;
echo "<br>";

$k=15;
$k %= 4;
echo $k;
?>  

</body>
</html>
