
<div class="row">
                            <div class="col-md-12">
                                <div class="main-card mb-3 card">
                                    <div class="card-header">Tutorial
                                        
                                    </div>
                                    <div class="table-responsive">
                                        <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Lesson</th>
                <th>Programming</th>
                <th>Topic</th>
                <th>Subtopic</th>
                <th>Result</th>
            </tr>
        </thead>
        <tbody>
            
       <tr>
                <td>2a</td>
                <td>PHP</td>
                <td>Syntax</td>
                <td>Basic PHP Syntax</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr>
                <td>2b</td>
                <td>PHP</td>
                <td>Syntax</td>
                <td>Write a Comment in PHP</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr>
                <td>2c</td>
                <td>PHP</td>
                <td>Syntax</td>
                <td>PHP Case Sensitivity</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
              <tr>
                <td>3a</td>
                <td>PHP</td>
                <td>Variable</td>
                <td>Creating (Declaring) PHP Variables</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr>
                <td>3b</td>
                <td>PHP</td>
                <td>Variable</td>
                <td>PHP Variables Scope: Local & Global</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr>
                <td>3c</td>
                <td>PHP</td>
                <td>Variable</td>
                <td>PHP Variables Scope: Global</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr>
                <td>3d</td>
                <td>PHP</td>
                <td>Variable</td>
                <td>PHP Variables Scope: Global</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr>
                <td>3e</td>
                <td>PHP</td>
                <td>Variable</td>
                <td>PHP Variables Scope: Static</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr>
                <td>3f-a</td>
                <td>PHP</td>
                <td>Variable</td>
                <td>PHP Variables Scope: Functions Parameters Scope</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr>
                <td>3f-b</td>
                <td>PHP</td>
                <td>Variable</td>
                <td>PHP Variables Scope: Functions Parameters Scope</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr>
                <td>3g</td>
                <td>PHP</td>
                <td>Variable</td>
                <td>PHP Variables: String</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>4a</td>
                <td>PHP</td>
                <td>Operators</td>
                <td>Arithmetical Operators</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>4b</td>
                <td>PHP</td>
                <td>Operators</td>
                <td>Assignment Operators</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>4c</td>
                <td>PHP</td>
                <td>Operators</td>
                <td>String Operators</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>4d</td>
                <td>PHP</td>
                <td>Operators</td>
                <td>Comparison Operators</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>4e</td>
                <td>PHP</td>
                <td>Operators</td>
                <td>PHP Incrementing/Decrementing Operators</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>4f</td>
                <td>PHP</td>
                <td>Operators</td>
                <td>Logical Operators</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>4g</td>
                <td>PHP</td>
                <td>Operators</td>
                <td>Conditional Operators</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>5a</td>
                <td>PHP</td>
                <td>Conditional Statement</td>
                <td>if statement</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>5b</td>
                <td>PHP</td>
                <td>Conditional Statement</td>
                <td>if else statement</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>5c</td>
                <td>PHP</td>
                <td>Conditional Statement</td>
                <td>if else if statement</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>5d</td>
                <td>PHP</td>
                <td>Conditional Statement</td>
                <td>Switch statement</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>6a</td>
                <td>PHP</td>
                <td>Loop</td>
                <td>The for Loop</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>6b</td>
                <td>PHP</td>
                <td>Loop</td>
                <td>The While Loop</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>6c</td>
                <td>PHP</td>
                <td>Loop</td>
                <td>The do....While Loop</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>6d</td>
                <td>PHP</td>
                <td>Loop</td>
                <td>The foreach Loop</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>7a</td>
                <td>PHP</td>
                <td>Array</td>
                <td>Numeric or Indexed Array</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>7b</td>
                <td>PHP</td>
                <td>Array</td>
                <td>Get The Length of an Array</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>7c</td>
                <td>PHP</td>
                <td>Array</td>
                <td>Loop Through an Indexed Array</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>7d</td>
                <td>PHP</td>
                <td>Array</td>
                <td>Associate array or Hash Array</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>7e</td>
                <td>PHP</td>
                <td>Array</td>
                <td>Loop Through an Associative Array</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>7f</td>
                <td>PHP</td>
                <td>Array</td>
                <td>Multidimensional Array</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>7g</td>
                <td>PHP</td>
                <td>Array</td>
                <td>Sort(), rsort() function Array</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>7h</td>
                <td>PHP</td>
                <td>Array</td>
                <td>asort(), ksort() function Array</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>8a</td>
                <td>PHP</td>
                <td>Function</td>
                <td>Writing PHP Function</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>8b</td>
                <td>PHP</td>
                <td>Function</td>
                <td>Writing PHP Function with Parameters</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>8c</td>
                <td>PHP</td>
                <td>Function</td>
                <td>Writing PHP Function which returns value</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>9a</td>
                <td>PHP</td>
                <td>Form</td>
                <td>A Simple HTML Form Using POST Method</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>9b</td>
                <td>PHP</td>
                <td>Form</td>
                <td>method="post"</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>9c</td>
                <td>PHP</td>
                <td>Form</td>
                <td>method="get"</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
            <tr> 
                <td>9d</td>
                <td>PHP</td>
                <td>Form</td>
                <td>PHP Handling</td>
                <td><button class="btn-transition btn btn-outline-info"><a href="http://localhost/exercise/2%20Syntax/Lesson%202a-s.php"    target="_blank"><i class="fa fa-clipboard "> </i>  File</a> </button>
                </td>
            </tr>
         </tbody>
        <tfoot>
            <tr>
                <th>Lesson</th>
                <th>Programming</th>
                <th>Topic</th>
                <th>Subtopic</th>
                <th>Result</th>
            </tr>
        </tfoot>
    </table>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        
                    </div>