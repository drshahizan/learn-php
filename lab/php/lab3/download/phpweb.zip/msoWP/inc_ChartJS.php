 <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="pe-7s-graph2 icon-gradient bg-mean-fruit">
                                        </i>
                                    </div>
                                    <div>ChartJS
                                        <div class="page-title-subheading">Huge selection of charts created with the React ChartJS Plugin
                                        </div>
                                    </div>
                                </div>                                   
                            </div>    
                        </div>

<ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                            <li class="nav-item">
                                <a role="tab" class="nav-link active" id="tab-0" data-toggle="tab" href="#tab-content-0">
                                    <span>Circular Charts</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a role="tab" class="nav-link" id="tab-1" data-toggle="tab" href="#tab-content-1">
                                    <span>Lines & Bars Charts</span>
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="main-card mb-3 card">
                                            <div class="card-body">
                                                <h5 class="card-title">Pie Chart</h5>
                                                <canvas id="chart-area"></canvas>
                                            </div>
                                        </div>
                                        <div class="main-card mb-3 card">
                                            <div class="card-body">
                                                <h5 class="card-title">Radar Chart</h5>
                                                <canvas id="radar-chart"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="main-card mb-3 card">
                                            <div class="card-body">
                                                <h5 class="card-title">Doughnut</h5>
                                                <canvas id="doughnut-chart"></canvas>
                                            </div>
                                        </div>
                                        <div class="main-card mb-3 card">
                                            <div class="card-body">
                                                <h5 class="card-title">Polar Chart</h5>
                                                <canvas id="polar-chart"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                </div>
            
                            </div>
                            <div class="tab-pane tabs-animation fade" id="tab-content-1" role="tabpanel">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="main-card mb-3 card">
                                            <div class="card-body">
                                                <h5 class="card-title">Vertical Bars</h5>
                                                <canvas id="canvas"></canvas>
                                            </div>
                                        </div>
                                        <div class="main-card mb-3 card">
                                            <div class="card-body">
                                                <h5 class="card-title">Horizontal Bars</h5>
                                                <canvas id="chart-horiz-bar"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="main-card mb-3 card">
                                            <div class="card-body">
                                                <h5 class="card-title">Line Chart</h5>
                                                <div style="height: 400px">
                                                    <canvas id="line-chart"></canvas>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="main-card mb-3 card">
                                            <div class="card-body">
                                                <h5 class="card-title">Stacked Bars</h5>
                                                <canvas id="stacked-bars-chart"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                </div>
