 <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="pe-7s-pen icon-gradient bg-mean-fruit">
                                        </i>
                                    </div>
                                    <div>Hypertext Preprocessor (PHP)
                                        <div class="page-title-subheading">PHP is a popular general-purpose scripting language that is especially suited to web development.
                                        </div>
                                    </div>
                                </div>                                   
                            </div>    
                        </div>