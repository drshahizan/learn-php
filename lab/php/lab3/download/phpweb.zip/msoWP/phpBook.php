<!doctype html>
<html lang="en">

<head>
<?php include('inc_metadata.php');?>
</head>
<body>
    
    <!-- +++++ Setting icon Section +++++ -->
        <?php include('inc_header.php');?> 
    
    <!-- +++++ Setting icon Section +++++ -->
        <?php include('inc_setting.php');?>  
            
    <!-- +++++ Navigation Sidebar left Section +++++ -->
        <?php include('inc_navleft.php');?>  
        
    <!-- +++++ Title Section +++++ -->    
        <?php include('inc_title.php');?>     

    <!-- +++++ Content Section +++++ -->                 
        <?php include('inc_phpBook.php');?>
	
    <!-- +++++ Footer Section +++++ -->
	   <?php include('inc_footer.php');?>
        
    </body>
</html>