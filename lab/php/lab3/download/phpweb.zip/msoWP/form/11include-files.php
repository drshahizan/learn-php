<!DOCTYPE html>
<html lang="en">
<head>
    <title>Include Files</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
    
<body>
<?php include "11header.php"; ?>
<div class="container">
    <h1>Welcome to Our Website!</h1>
    <p>Here you will find lots of useful information.</p>
    <br>
</div>
<?php include "11footer.php"; ?>
</body>
</html>